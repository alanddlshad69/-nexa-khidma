# Nexa Khidma — Production launch checklist

## Included in code
- Web UI + backend
- Mobile Expo app
- JWT authentication
- Password hashing
- SQLite persistence
- Customer/provider flows
- Provider verification
- Booking lifecycle
- Reviews
- Notifications API
- Chat API
- Provider booking management
- Provider profile management
- Admin dashboard/API
- Responsive web styling
- Mobile build configuration

## External items that cannot be fabricated inside source code
1. Production domain/DNS
2. HTTPS certificate
3. Production hosting
4. Production database/backup plan
5. Real payment gateway merchant account + API credentials
6. SMS/email provider credentials
7. Maps provider key
8. Push notification credentials
9. Google Play developer account / Apple Developer account
10. Business/legal documents, privacy policy, terms, refund policy, tax/compliance review

## Before public launch
- Replace all development secrets.
- Set environment variables.
- Put backend behind HTTPS.
- Use a production database and automated backups.
- Add rate limiting, request validation, CSRF/CORS policy as appropriate, audit logs.
- Configure payment webhooks and reconciliation if payments are enabled.
- Test authentication, booking, cancellation, reviews and admin permissions.
- Run dependency/security audits.
- Build signed Android release and test on physical devices.
