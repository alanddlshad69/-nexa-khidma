# Nexa Khidma — Complete MVP

## پێویستییەکان
- Node.js 18+ 
- npm

## Run
1. terminal بکەرەوە لەم folder ـە.
2. `npm install`
3. `.env.example` بکە بە `.env` و JWT_SECRET ـەکە بگۆڕە.
4. `npm start`
5. browser بکەرەوە: `http://localhost:3000`

## Demo Admin
Email: `admin@nexakhidma.local`
Password: `Demo1234!`

## ئەم وەشانە چی هەیە؟
- Frontend RTL/Responsive
- User registration/login
- JWT authentication
- SQLite database
- Provider profiles
- Provider application
- Service search/filter
- Booking creation
- My bookings
- Reviews API
- Admin statistics/providers/bookings API
- Provider verification API
- Booking status management API

## تێبینی
ئەمە MVP ـی functional ـە، بەڵام پێش بەکارهێنانی public production پێویستە:
- HTTPS
- secret ـی بەهێز
- email/phone verification
- rate limiting
- validation/security hardening
- backups
- real payment provider
- privacy/terms/copyright policies
- monitoring/logging
- production database
- legal/business review

Payment ـی ڕاستەقینە لەم وەشانەدا نییە؛ تەنها architecture ـەکە ئامادەی زیادکردنیە.
