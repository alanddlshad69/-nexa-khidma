const express=require("express");
const path=require("path");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const Database=require("better-sqlite3");

const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"nexa-dev-secret-change-me";
const db=new Database(path.join(__dirname,"data","nexa.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'customer',phone TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS providers(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,service TEXT NOT NULL,city TEXT NOT NULL,
 bio TEXT DEFAULT '',verified INTEGER DEFAULT 0,rating REAL DEFAULT 5,
 jobs INTEGER DEFAULT 0,available INTEGER DEFAULT 1,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS bookings(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_id INTEGER NOT NULL,provider_id INTEGER NOT NULL,
 service TEXT NOT NULL,address TEXT NOT NULL,booking_date TEXT NOT NULL,
 notes TEXT DEFAULT '',status TEXT DEFAULT 'pending',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES users(id),
 FOREIGN KEY(provider_id) REFERENCES providers(id)
);
CREATE TABLE IF NOT EXISTS reviews(
 id INTEGER PRIMARY KEY AUTOINCREMENT,booking_id INTEGER NOT NULL,
 customer_id INTEGER NOT NULL,provider_id INTEGER NOT NULL,
 rating INTEGER NOT NULL,comment TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT,sender_id INTEGER NOT NULL,receiver_id INTEGER NOT NULL,
 booking_id INTEGER,body TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,read_at TEXT
);
CREATE TABLE IF NOT EXISTS notifications(
 id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,title TEXT NOT NULL,
 body TEXT NOT NULL,type TEXT DEFAULT 'info',read_at TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

function seed(){
  const count=db.prepare("SELECT COUNT(*) c FROM users").get().c;
  if(count) return;
  const pass=bcrypt.hashSync("Demo1234!",10);
  const admin=db.prepare("INSERT INTO users(name,email,password,role,phone) VALUES(?,?,?,?,?)")
    .run("Nexa Admin","admin@nexakhidma.local",pass,"admin","07500000000");
  const names=[
    ["ئارام حەمە","aram@nexakhidma.local","کارەبا","هەولێر"],
    ["دانا کەریم","dana@nexakhidma.local","AC","هەولێر"],
    ["سوران کەمال","soran@nexakhidma.local","پلامبینگ","هەولێر"],
    ["هیوا عەلی","hiwa@nexakhidma.local","کۆمپیوتەر","هەولێر"],
    ["ژین ئەحمەد","zhin@nexakhidma.local","پاککردنەوە","هەولێر"]
  ];
  for(const [name,email,service,city] of names){
    const u=db.prepare("INSERT INTO users(name,email,password,role,phone) VALUES(?,?,?,?,?)")
      .run(name,email,pass,"provider","07500000000");
    db.prepare("INSERT INTO providers(user_id,service,city,bio,verified,rating,jobs) VALUES(?,?,?,?,?,?,?)")
      .run(u.lastInsertRowid,service,city,`پیشەکاری ${service} ـی پشتڕاستکراو.`,1,4.9,20);
  }
}
seed();

app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

function auth(req,res,next){
  const h=req.headers.authorization||"";
  const token=h.startsWith("Bearer ")?h.slice(7):null;
  if(!token) return res.status(401).json({error:"پێویستە بچیتە ژوورەوە"});
  try{req.user=jwt.verify(token,JWT_SECRET);next();}
  catch{return res.status(401).json({error:"Session بەسەرچووە"});}
}
function admin(req,res,next){ if(req.user.role!=="admin") return res.status(403).json({error:"دەستپێگەیشتن ڕێگەپێنەدراوە"}); next(); }
function notify(userId,title,body,type="info"){
  db.prepare("INSERT INTO notifications(user_id,title,body,type) VALUES(?,?,?,?)").run(userId,title,body,type);
}

app.post("/api/register",(req,res)=>{
  const {name,email,password,phone=""}=req.body;
  if(!name||!email||!password) return res.status(400).json({error:"ناو، ئیمەیڵ و وشەی نهێنی پێویستن"});
  if(password.length<6) return res.status(400).json({error:"وشەی نهێنی دەبێت لانیکەم 6 پیت بێت"});
  try{
    const hash=bcrypt.hashSync(password,10);
    const r=db.prepare("INSERT INTO users(name,email,password,phone) VALUES(?,?,?,?)").run(name,email.toLowerCase(),hash,phone);
    const user={id:r.lastInsertRowid,name,email:email.toLowerCase(),role:"customer"};
    const token=jwt.sign(user,JWT_SECRET,{expiresIn:"7d"});
    res.json({token,user});
  }catch(e){res.status(409).json({error:"ئەم ئیمەیڵە پێشتر تۆمارکراوە"});}
});

app.post("/api/login",(req,res)=>{
  const {email,password}=req.body;
  const u=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").toLowerCase());
  if(!u||!bcrypt.compareSync(password||"",u.password)) return res.status(401).json({error:"ئیمەیڵ یان وشەی نهێنی هەڵەیە"});
  const user={id:u.id,name:u.name,email:u.email,role:u.role,phone:u.phone};
  const token=jwt.sign(user,JWT_SECRET,{expiresIn:"7d"});
  res.json({token,user});
});

app.get("/api/me",auth,(req,res)=>res.json({user:req.user}));

app.get("/api/services",(req,res)=>{
  const rows=db.prepare(`
    SELECT p.id,p.service,p.city,p.bio,p.verified,p.rating,p.jobs,p.available,u.name,u.phone
    FROM providers p JOIN users u ON u.id=p.user_id
    WHERE p.available=1 ORDER BY p.rating DESC
  `).all();
  res.json(rows);
});

app.get("/api/providers/:id",(req,res)=>{
  const p=db.prepare(`SELECT p.*,u.name,u.phone,u.email FROM providers p JOIN users u ON u.id=p.user_id WHERE p.id=?`).get(req.params.id);
  if(!p) return res.status(404).json({error:"پیشەکار نەدۆزرایەوە"});
  res.json(p);
});

app.post("/api/providers/apply",auth,(req,res)=>{
  const {service,city,bio=""}=req.body;
  if(!service||!city) return res.status(400).json({error:"خزمەت و شار پێویستن"});
  const exists=db.prepare("SELECT id FROM providers WHERE user_id=?").get(req.user.id);
  if(exists) return res.status(409).json({error:"پروفایلی پیشەکاریت هەیە"});
  const r=db.prepare("INSERT INTO providers(user_id,service,city,bio,verified) VALUES(?,?,?,?,0)")
    .run(req.user.id,service,city,bio);
  db.prepare("UPDATE users SET role='provider' WHERE id=?").run(req.user.id);
  res.json({id:r.lastInsertRowid,message:"داواکارییەکەت نێردراوە بۆ پشتڕاستکردنەوە"});
});

app.post("/api/bookings",auth,(req,res)=>{
  const {providerId,service,address,date,notes=""}=req.body;
  if(!providerId||!service||!address||!date) return res.status(400).json({error:"هەموو خانە پێویستەکان پڕبکەرەوە"});
  const p=db.prepare("SELECT * FROM providers WHERE id=? AND available=1").get(providerId);
  if(!p) return res.status(404).json({error:"پیشەکار بەردەست نییە"});
  const r=db.prepare(`INSERT INTO bookings(customer_id,provider_id,service,address,booking_date,notes) VALUES(?,?,?,?,?,?)`)
    .run(req.user.id,providerId,service,address,date,notes);
  notify(p.user_id,"داواکارییەکی نوێ",`داواکاری بۆ ${service}`,"booking");
  res.json({id:r.lastInsertRowid,status:"pending"});
});

app.get("/api/my-bookings",auth,(req,res)=>{
  const rows=db.prepare(`
    SELECT b.*,u.name provider_name,p.city FROM bookings b
    JOIN providers p ON p.id=b.provider_id JOIN users u ON u.id=p.user_id
    WHERE b.customer_id=? ORDER BY b.id DESC
  `).all(req.user.id);
  res.json(rows);
});

app.post("/api/reviews",auth,(req,res)=>{
  const {bookingId,rating,comment=""}=req.body;
  const b=db.prepare("SELECT * FROM bookings WHERE id=? AND customer_id=? AND status='completed'").get(bookingId,req.user.id);
  if(!b) return res.status(400).json({error:"تەنها booking ـی تەواوبوو دەتوانرێت هەڵسەنگێنرێت"});
  if(rating<1||rating>5) return res.status(400).json({error:"نمرە دەبێت 1 تا 5 بێت"});
  db.prepare("INSERT INTO reviews(booking_id,customer_id,provider_id,rating,comment) VALUES(?,?,?,?,?)")
    .run(bookingId,req.user.id,b.provider_id,rating,comment);
  const avg=db.prepare("SELECT AVG(rating) a,COUNT(*) c FROM reviews WHERE provider_id=?").get(b.provider_id);
  db.prepare("UPDATE providers SET rating=?,jobs=jobs+1 WHERE id=?").run(Number(avg.a.toFixed(2)),b.provider_id);
  res.json({message:"سوپاس بۆ هەڵسەنگاندن"});
});


app.get("/api/notifications",auth,(req,res)=>{
  res.json(db.prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50").all(req.user.id));
});
app.patch("/api/notifications/:id/read",auth,(req,res)=>{
  db.prepare("UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?").run(req.params.id,req.user.id);
  res.json({message:"خوێندرایەوە"});
});

app.get("/api/chats/:userId",auth,(req,res)=>{
  const other=Number(req.params.userId);
  res.json(db.prepare(`SELECT m.*,su.name sender_name,ru.name receiver_name
    FROM messages m JOIN users su ON su.id=m.sender_id JOIN users ru ON ru.id=m.receiver_id
    WHERE (m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?)
    ORDER BY m.id ASC`).all(req.user.id,other,other,req.user.id));
});
app.post("/api/chats/:userId",auth,(req,res)=>{
  const body=(req.body.body||"").trim();
  const receiver=Number(req.params.userId);
  if(!body) return res.status(400).json({error:"پەیام بەتاڵە"});
  const u=db.prepare("SELECT id FROM users WHERE id=?").get(receiver);
  if(!u) return res.status(404).json({error:"بەکارهێنەر نەدۆزرایەوە"});
  const r=db.prepare("INSERT INTO messages(sender_id,receiver_id,body) VALUES(?,?,?)").run(req.user.id,receiver,body);
  notify(receiver,"پەیامی نوێ",body.slice(0,120),"message");
  res.json({id:r.lastInsertRowid});
});

app.get("/api/provider/bookings",auth,(req,res)=>{
  const p=db.prepare("SELECT id FROM providers WHERE user_id=?").get(req.user.id);
  if(!p) return res.status(403).json({error:"پڕۆفایلی پیشەکار نییە"});
  res.json(db.prepare(`SELECT b.*,u.name customer_name,u.phone customer_phone
    FROM bookings b JOIN users u ON u.id=b.customer_id WHERE b.provider_id=? ORDER BY b.id DESC`).all(p.id));
});
app.patch("/api/provider/bookings/:id",auth,(req,res)=>{
  const p=db.prepare("SELECT id FROM providers WHERE user_id=?").get(req.user.id);
  if(!p) return res.status(403).json({error:"پیشەکار نییت"});
  const allowed=["confirmed","completed","cancelled"];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:"status هەڵەیە"});
  const b=db.prepare("SELECT * FROM bookings WHERE id=? AND provider_id=?").get(req.params.id,p.id);
  if(!b) return res.status(404).json({error:"داواکاری نەدۆزرایەوە"});
  db.prepare("UPDATE bookings SET status=? WHERE id=?").run(req.body.status,b.id);
  notify(b.customer_id,"نوێکردنەوەی داواکاری",`داواکاری #${b.id} بوو بە ${req.body.status}`,"booking");
  res.json({message:"نوێکرایەوە"});
});

app.get("/api/providers/me",auth,(req,res)=>{
  const p=db.prepare(`SELECT p.*,u.name,u.email,u.phone FROM providers p JOIN users u ON u.id=p.user_id WHERE p.user_id=?`).get(req.user.id);
  if(!p) return res.status(404).json({error:"پڕۆفایل نییە"});
  res.json(p);
});
app.patch("/api/providers/me",auth,(req,res)=>{
  const fields=["service","city","bio","available"];
  const p=db.prepare("SELECT id FROM providers WHERE user_id=?").get(req.user.id);
  if(!p) return res.status(404).json({error:"پڕۆفایل نییە"});
  if(req.body.service!=null) db.prepare("UPDATE providers SET service=? WHERE id=?").run(req.body.service,p.id);
  if(req.body.city!=null) db.prepare("UPDATE providers SET city=? WHERE id=?").run(req.body.city,p.id);
  if(req.body.bio!=null) db.prepare("UPDATE providers SET bio=? WHERE id=?").run(req.body.bio,p.id);
  if(req.body.available!=null) db.prepare("UPDATE providers SET available=? WHERE id=?").run(req.body.available?1:0,p.id);
  res.json({message:"پڕۆفایل نوێکرایەوە"});
});

app.get("/api/admin/stats",auth,admin,(req,res)=>{
  res.json({
    users:db.prepare("SELECT COUNT(*) c FROM users WHERE role='customer'").get().c,
    providers:db.prepare("SELECT COUNT(*) c FROM providers").get().c,
    bookings:db.prepare("SELECT COUNT(*) c FROM bookings").get().c,
    pending:db.prepare("SELECT COUNT(*) c FROM bookings WHERE status='pending'").get().c
  });
});

app.get("/api/admin/providers",auth,admin,(req,res)=>{
  res.json(db.prepare(`SELECT p.*,u.name,u.email,u.phone FROM providers p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC`).all());
});

app.patch("/api/admin/providers/:id",auth,admin,(req,res)=>{
  const {verified,available}=req.body;
  db.prepare("UPDATE providers SET verified=COALESCE(?,verified),available=COALESCE(?,available) WHERE id=?")
    .run(verified==null?null:Number(verified),available==null?null:Number(available),req.params.id);
  res.json({message:"نوێکرایەوە"});
});

app.get("/api/admin/bookings",auth,admin,(req,res)=>{
  res.json(db.prepare(`SELECT b.*,cu.name customer_name,pu.name provider_name FROM bookings b
    JOIN users cu ON cu.id=b.customer_id JOIN providers p ON p.id=b.provider_id
    JOIN users pu ON pu.id=p.user_id ORDER BY b.id DESC`).all());
});

app.patch("/api/admin/bookings/:id",auth,admin,(req,res)=>{
  const allowed=["pending","confirmed","completed","cancelled"];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:"status هەڵەیە"});
  db.prepare("UPDATE bookings SET status=? WHERE id=?").run(req.body.status,req.params.id);
  res.json({message:"نوێکرایەوە"});
});

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));\napp.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Nexa Khidma running on http://localhost:${PORT}`));
