# Nexa Khidma Mobile

ئەمە ئەپی Android/iOS ـە بە Expo/React Native.

## پێویستی
Node.js 18+
Expo CLI (npx دەتوانێت بیهێنێت)

## Run
1. `npm install`
2. لە `App.js` ـدا `API` بگۆڕە بۆ IP ـی کۆمپیوتەرەکەت، بۆ نموونە:
   `http://192.168.1.20:3000`
3. Backend ـی سەرەکی لە parent folder run بکە:
   `npm install`
   `npm start`
4. لە mobile:
   `npm start`
5. Expo Go لە مۆبایل بەکاربهێنە یان Android emulator.

## APK/AAB
بۆ build ـی production:
`npx eas login`
`npx eas build:configure`
`npx eas build -p android --profile production`

پێش publish ـکردن API ـەکە دەبێت HTTPS و domain ـی production هەبێت.

API endpoints also include notifications, chat, provider bookings and provider profile management.
