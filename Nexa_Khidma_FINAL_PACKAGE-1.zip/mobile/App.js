import React,{useEffect,useState} from "react";
import {Alert,FlatList,SafeAreaView,ScrollView,StatusBar,StyleSheet,Text,TextInput,TouchableOpacity,View} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const API="http://YOUR_COMPUTER_IP:3000";
const GREEN="#55e29a",BG="#07100e",CARD="#0d1c17",MUTED="#91a49c";
const services=[["⚡","کارەبا"],["🚰","پلامبینگ"],["❄️","AC"],["💻","کۆمپیوتەر"],["🧹","پاککردنەوە"]];

function Btn({children,onPress,ghost=false}){return <TouchableOpacity onPress={onPress} style={[s.btn,ghost&&s.ghost]}><Text style={[s.btnText,ghost&&{color:"#eef7f2"}]}>{children}</Text></TouchableOpacity>}
function Input({value,onChangeText,placeholder,secureTextEntry=false}){return <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#60736b" secureTextEntry={secureTextEntry} style={s.input}/>}

export default function App(){
 const [screen,setScreen]=useState("home"),[token,setToken]=useState(null),[me,setMe]=useState(null);
 const [providers,setProviders]=useState([]),[bookings,setBookings]=useState([]),[search,setSearch]=useState("");
 const [authMode,setAuthMode]=useState("login"),[form,setForm]=useState({name:"",email:"",password:"",phone:""});
 const [selected,setSelected]=useState(null),[address,setAddress]=useState(""),[date,setDate]=useState(""),[notes,setNotes]=useState("");

 useEffect(()=>{AsyncStorage.getItem("nexa_token").then(t=>{if(t){setToken(t);loadMe(t)}});loadProviders()},[]);
 async function api(path,opt={}){
   const headers={"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})};
   const r=await fetch(API+path,{...opt,headers:{...headers,...(opt.headers||{})}});
   const d=await r.json(); if(!r.ok)throw Error(d.error||"هەڵە"); return d;
 }
 async function loadMe(t=token){try{const h={"Authorization":"Bearer "+t};const r=await fetch(API+"/api/me",{headers:h});const d=await r.json();setMe(d.user)}catch{}}
 async function loadProviders(){try{const r=await fetch(API+"/api/services");setProviders(await r.json())}catch{}}
 async function login(){
   try{const d=await api("/api/"+(authMode==="login"?"login":"register"),{method:"POST",body:JSON.stringify(form)});
     setToken(d.token);setMe(d.user);await AsyncStorage.setItem("nexa_token",d.token);setScreen("home");
   }catch(e){Alert.alert("هەڵە",e.message)}
 }
 async function loadBookings(){if(!token)return;try{setBookings(await api("/api/my-bookings"))}catch{}}
 async function createBooking(){
   if(!token){setScreen("auth");return}
   if(!address||!date){Alert.alert("تکایە","ناونیشان و کات پڕبکەرەوە");return}
   try{await api("/api/bookings",{method:"POST",body:JSON.stringify({providerId:selected.id,service:selected.service,address,date,notes})});
     Alert.alert("سەرکەوتوو","داواکارییەکەت نێردرا");setSelected(null);setScreen("bookings");loadBookings();
   }catch(e){Alert.alert("هەڵە",e.message)}
 }
 function logout(){setToken(null);setMe(null);AsyncStorage.removeItem("nexa_token");setScreen("home")}
 const filtered=providers.filter(p=>(p.service+" "+p.name+" "+p.city).toLowerCase().includes(search.toLowerCase()));
 function Header(){return <View style={s.header}><Text style={s.logo}>Nexa <Text style={{color:GREEN}}>Khidma</Text></Text>{token?<TouchableOpacity onPress={logout}><Text style={s.link}>دەرچوون</Text></TouchableOpacity>:<TouchableOpacity onPress={()=>setScreen("auth")}><Text style={s.link}>چوونەژوورەوە</Text></TouchableOpacity>}</View>}
 function Home(){return <ScrollView contentContainerStyle={s.page}>
   <Text style={s.tag}>NEXA KHIDMA</Text><Text style={s.hero}>خزمەتگوزارییەکانت{`\n`}<Text style={{color:GREEN}}>بە ئاسانی</Text> بدۆزەوە.</Text>
   <Text style={s.muted}>کڕیار و پیشەکار لە یەک پلاتفۆرمدا.</Text>
   <TextInput value={search} onChangeText={setSearch} placeholder="گەڕان بۆ خزمەت..." placeholderTextColor="#60736b" style={s.search}/>
   <Text style={s.title}>خزمەتگوزارییەکان</Text>
   <View style={s.serviceGrid}>{services.map(x=><TouchableOpacity key={x[1]} onPress={()=>setSearch(x[1])} style={s.service}><Text style={s.icon}>{x[0]}</Text><Text style={s.cardTitle}>{x[1]}</Text></TouchableOpacity>)}</View>
   <Text style={s.title}>پیشەکارەکان</Text>
   {filtered.map(p=><TouchableOpacity key={p.id} style={s.provider} onPress={()=>{setSelected(p);setScreen("book")}}>
     <View style={s.avatar}><Text style={{color:GREEN,fontWeight:"800"}}>{p.name.slice(0,2)}</Text></View>
     <View style={{flex:1}}><Text style={s.cardTitle}>{p.name} {p.verified?"✓":""}</Text><Text style={s.muted}>{p.service} • {p.city}</Text><Text style={s.rating}>★ {p.rating}</Text></View>
     <Text style={s.link}>داوا</Text>
   </TouchableOpacity>)}
 </ScrollView>}
 function Auth(){return <ScrollView contentContainerStyle={s.page}><Text style={s.tag}>ACCOUNT</Text><Text style={s.title}>{authMode==="login"?"چوونەژوورەوە":"تۆماربوون"}</Text>
   {authMode==="register"&&<Input placeholder="ناو" value={form.name} onChangeText={v=>setForm({...form,name:v})}/>}
   <Input placeholder="ئیمەیڵ" value={form.email} onChangeText={v=>setForm({...form,email:v})}/><Input placeholder="وشەی نهێنی" secureTextEntry value={form.password} onChangeText={v=>setForm({...form,password:v})}/>
   {authMode==="register"&&<Input placeholder="ژمارەی مۆبایل" value={form.phone} onChangeText={v=>setForm({...form,phone:v})}/>}
   <Btn onPress={login}>{authMode==="login"?"چوونەژوورەوە":"تۆماربوون"}</Btn>
   <Btn ghost onPress={()=>setAuthMode(authMode==="login"?"register":"login")}>{authMode==="login"?"هەژمارت نییە؟ تۆماربوون":"هەژمارت هەیە؟ چوونەژوورەوە"}</Btn>
   </ScrollView>}
 function Book(){return <ScrollView contentContainerStyle={s.page}><Text style={s.tag}>BOOKING</Text><Text style={s.title}>داواکاری بۆ {selected?.name}</Text><Text style={s.muted}>{selected?.service} • {selected?.city}</Text>
   <Input placeholder="ناونیشان" value={address} onChangeText={setAddress}/><Input placeholder="ڕێکەوت و کات: 2026-10-01 18:00" value={date} onChangeText={setDate}/><Input placeholder="تێبینی" value={notes} onChangeText={setNotes}/><Btn onPress={createBooking}>پشتڕاستکردنی داواکاری</Btn><Btn ghost onPress={()=>setScreen("home")}>گەڕانەوە</Btn>
   </ScrollView>}
 function Bookings(){useEffect(()=>{loadBookings()},[]);return <ScrollView contentContainerStyle={s.page}><Text style={s.tag}>MY BOOKINGS</Text><Text style={s.title}>داواکارییەکانم</Text>{bookings.map(b=><View style={s.booking} key={b.id}><Text style={s.cardTitle}>{b.service}</Text><Text style={s.muted}>{b.provider_name} • {b.booking_date}</Text><Text style={s.status}>{b.status}</Text></View>)}{!bookings.length&&<Text style={s.muted}>هێشتا هیچ داواکارییەکت نییە.</Text>}</ScrollView>}
 return <SafeAreaView style={s.root}><StatusBar barStyle="light-content"/><Header/>
 {screen==="home"&&<Home/>}{screen==="auth"&&<Auth/>}{screen==="book"&&<Book/>}{screen==="bookings"&&<Bookings/>}
 <View style={s.bottom}><TouchableOpacity onPress={()=>setScreen("home")}><Text style={s.tab}>⌂{"\n"}سەرەتا</Text></TouchableOpacity><TouchableOpacity onPress={()=>{setScreen("bookings");loadBookings()}}><Text style={s.tab}>▣{"\n"}داواکاری</Text></TouchableOpacity><TouchableOpacity onPress={()=>setScreen(token?"home":"auth")}><Text style={s.tab}>●{"\n"}هەژمار</Text></TouchableOpacity></View>
 </SafeAreaView>
}
const s=StyleSheet.create({
root:{flex:1,backgroundColor:BG},header:{height:64,paddingHorizontal:20,flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderBottomWidth:1,borderBottomColor:"#183129"},logo:{color:"#fff",fontSize:20,fontWeight:"800"},link:{color:GREEN,fontWeight:"700"},page:{padding:22,paddingBottom:110},tag:{color:GREEN,fontSize:11,fontWeight:"800",letterSpacing:2},hero:{fontSize:40,lineHeight:48,fontWeight:"800",color:"#fff",marginTop:12},muted:{color:MUTED,fontSize:13,lineHeight:22},search:{marginTop:25,background:CARD,borderWidth:1,borderColor:"#29483c",borderRadius:12,color:"#fff",padding:13},title:{fontSize:24,fontWeight:"800",color:"#fff",marginTop:30,marginBottom:15},serviceGrid:{flexDirection:"row",flexWrap:"wrap",gap:10},service:{width:"30%",minHeight:105,padding:13,background:CARD,borderRadius:15,borderWidth:1,borderColor:"#203b32"},icon:{fontSize:25},cardTitle:{color:"#edf7f2",fontWeight:"700",fontSize:14},provider:{flexDirection:"row",alignItems:"center",gap:12,padding:15,background:CARD,borderWidth:1,borderColor:"#203b32",borderRadius:15,marginBottom:10},avatar:{width:48,height:48,borderRadius:14,backgroundColor:"#18372a",alignItems:"center",justifyContent:"center"},rating:{color:"#eac55e",fontSize:12},btn:{backgroundColor:GREEN,padding:14,borderRadius:12,alignItems:"center",marginTop:12},ghost:{backgroundColor:"transparent",borderWidth:1,borderColor:"#315447"},btnText:{color:"#06100d",fontWeight:"800"},input:{backgroundColor:CARD,borderWidth:1,borderColor:"#29483c",borderRadius:11,color:"#fff",padding:13,marginTop:12},booking:{backgroundColor:CARD,borderWidth:1,borderColor:"#203b32",borderRadius:15,padding:16,marginBottom:10},status:{color:GREEN,marginTop:8,fontSize:11},bottom:{position:"absolute",bottom:0,left:0,right:0,height:72,backgroundColor:"#0a1713",borderTopWidth:1,borderTopColor:"#183129",flexDirection:"row",justifyContent:"space-around",alignItems:"center"},tab:{color:"#9eb0a9",fontSize:11,textAlign:"center"}
});