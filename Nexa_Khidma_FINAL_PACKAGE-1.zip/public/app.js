const services=[
  ["⚡","کارەبا","چاککردن و دامەزراندن"],
  ["🚰","پلامبینگ","ئاو و بۆری"],
  ["❄️","AC","چاککردن و سرویس"],
  ["💻","کۆمپیوتەر","کۆمپیوتەر و مۆبایل"],
  ["🧹","پاککردنەوە","خانوو و شوێنی کار"]
];
let providers=[];let token=localStorage.getItem("nexa_token");let me=null;

const $=s=>document.querySelector(s);
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function openModal(html){$("#modalBody").innerHTML=html;$("#modal").classList.remove("hidden")}
function closeModal(){$("#modal").classList.add("hidden")}
window.closeModal=closeModal;

async function api(url,opt={}){
  opt.headers={...(opt.headers||{}),"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})};
  const r=await fetch(url,opt);const d=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(d.error||"هەڵەیەک ڕوویدا");return d;
}

function renderServices(){
  $("#serviceGrid").innerHTML=services.map(s=>`<button class="service" onclick="chooseService('${s[1]}')"><div class="ico">${s[0]}</div><b>${s[1]}</b><small>${s[2]}</small></button>`).join("");
}
async function loadProviders(){
  providers=await api("/api/services");
  renderProviders(providers);
}
function renderProviders(list){
  $("#providerGrid").innerHTML=list.length?list.map(p=>`<article class="provider">
    <div class="avatar">${esc(p.name.slice(0,2))}</div><main><h3>${esc(p.name)} ${p.verified?'✓':''}</h3>
    <p>${esc(p.service)} • ${esc(p.city)}</p><div class="rating">★ ${p.rating} <span class="verify">${p.verified?'Verified':''}</span></div>
  </main><button class="btn" onclick="book(${p.id},'${esc(p.service)}','${esc(p.name)}')">داوا</button></article>`).join("")
  :`<p class="muted">هیچ پیشەکارێک نەدۆزرایەوە.</p>`;
}
$("#filter").addEventListener("input",e=>{
  const q=e.target.value.trim().toLowerCase();
  renderProviders(providers.filter(p=>(p.service+" "+p.name+" "+p.city).toLowerCase().includes(q)));
});

function authForm(mode){
  const login=mode==="login";
  openModal(`<span class="tag">NEXA KHIDMA</span><h2>${login?"چوونەژوورەوە":"تۆماربوون"}</h2>
  <form class="form" id="authForm">
  ${login?"":`<label>ناو</label><input name="name" required placeholder="ناوی تەواو">`}
  <label>ئیمەیڵ</label><input name="email" type="email" required placeholder="example@mail.com">
  <label>وشەی نهێنی</label><input name="password" type="password" required minlength="6" placeholder="لانیکەم 6 پیت">
  ${login?"":`<label>ژمارەی مۆبایل</label><input name="phone" placeholder="07xx xxx xxxx">`}
  <button class="btn" type="submit">${login?"چوونەژوورەوە":"تۆماربوون"}</button>
  </form>
  <p class="muted">Demo admin: admin@nexakhidma.local / Demo1234!</p>`);
  $("#authForm").onsubmit=async e=>{
    e.preventDefault();const body=Object.fromEntries(new FormData(e.target));
    try{const d=await api(login?"/api/login":"/api/register",{method:"POST",body:JSON.stringify(body)});
      token=d.token;localStorage.setItem("nexa_token",token);me=d.user;closeModal();updateNav();loadBookings();
    }catch(err){alert(err.message)}
  };
}
$("#loginBtn").onclick=()=>authForm("login");
$("#registerBtn").onclick=()=>authForm("register");
$("#logoutBtn").onclick=()=>{token=null;me=null;localStorage.removeItem("nexa_token");updateNav();loadBookings()};
function updateNav(){
  $("#loginBtn").classList.toggle("hidden",!!token);$("#registerBtn").classList.toggle("hidden",!!token);$("#logoutBtn").classList.toggle("hidden",!token);
}
async function chooseService(service){
  $("#filter").value=service;document.querySelector("#providers").scrollIntoView({behavior:"smooth"});
  renderProviders(providers.filter(p=>p.service===service));
}
window.chooseService=chooseService;

async function book(id,service,name){
  if(!token){authForm("login");return}
  openModal(`<span class="tag">BOOKING</span><h2>داواکاری بۆ ${esc(name)}</h2>
  <form class="form" id="bookForm"><input name="address" required placeholder="ناونیشانی شوێن"><input name="date" type="datetime-local" required><textarea name="notes" placeholder="تێبینی زیادە"></textarea>
  <button class="btn" type="submit">پشتڕاستکردنی داواکاری</button></form>`);
  $("#bookForm").onsubmit=async e=>{
    e.preventDefault();const b=Object.fromEntries(new FormData(e.target));b.providerId=id;b.service=service;
    try{await api("/api/bookings",{method:"POST",body:JSON.stringify(b)});closeModal();alert("داواکارییەکەت نێردرا.");loadBookings()}catch(err){alert(err.message)}
  }
}
window.book=book;

async function loadBookings(){
  if(!token){$("#bookingList").innerHTML='<p class="muted">بۆ بینینی داواکارییەکانت بچۆ ژوورەوە.</p>';return}
  try{const rows=await api("/api/my-bookings");
    $("#bookingList").innerHTML=rows.length?rows.map(b=>`<div class="booking"><div><b>${esc(b.service)}</b><p class="muted">${esc(b.provider_name)} • ${esc(b.city)} • ${esc(b.booking_date)}</p></div><span class="status">${esc(b.status)}</span></div>`).join(""):'<p class="muted">هێشتا هیچ داواکارییەکت نییە.</p>';
  }catch(e){$("#bookingList").innerHTML=`<p class="muted">${e.message}</p>`}
}

$("#becomeBtn").onclick=()=>{
 if(!token){authForm("login");return}
 openModal(`<span class="tag">PROVIDER</span><h2>بەشێک لە Nexa Khidma بە</h2>
 <form class="form" id="providerForm"><label>خزمەت</label><select name="service" required>${services.map(s=>`<option>${s[1]}</option>`).join("")}</select>
 <input name="city" required placeholder="شار"><textarea name="bio" placeholder="کورتەیەک دەربارەی کارەکەت"></textarea>
 <button class="btn" type="submit">ناردنی داواکاری</button></form>`);
 $("#providerForm").onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(e.target));try{await api("/api/providers/apply",{method:"POST",body:JSON.stringify(b)});closeModal();alert("داواکارییەکەت نێردرا.");}catch(err){alert(err.message)}}
};

(async()=>{renderServices();try{if(token){const d=await api("/api/me");me=d.user}}catch{token=null;localStorage.removeItem("nexa_token")}updateNav();await loadProviders();await loadBookings()})();
