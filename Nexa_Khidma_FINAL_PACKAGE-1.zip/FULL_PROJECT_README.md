# Nexa Khidma — Full Web + Mobile Package

ئەم package ـە دوو بەشی سەرەکی هەیە:

1. Web + Backend لە root
2. Mobile app لە `mobile/`

Web:
- Node.js + Express
- SQLite
- JWT
- Registration/Login
- Provider registration/verification
- Services/search
- Booking
- Reviews API
- Admin APIs

Mobile:
- Expo + React Native
- Kurdish RTL-style UI
- Login/Register
- Services
- Provider browsing
- Booking
- My bookings
- Local token storage

## گرنگ
Payment gateway ـی ڕاستەقینە، SMS/WhatsApp، maps، push notifications و production deployment پێویستی بە API keys/account ـی دەرەکی هەیە؛ لە package ـەکەدا architecture ـی بنەڕەتی هەیە، بەڵام key ـی ساختە دانانرێت.

ئەم package ـە production-ready بە مانای "publish immediately without security review" نییە. پێش public launch پێویستە security، privacy/terms، payment provider، HTTPS، backups و testing تەواو بکرێت.
